<?php defined('SYSPATH') or die('No direct script access.');

class HTTP_Exception_416 extends Kohana_HTTP_Exception_416 {}