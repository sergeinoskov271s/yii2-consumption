<?php defined('SYSPATH') or die('No direct script access.');

require Kohana::find_file('classes','Swift-5.0.3/lib/swift_required');
